#ifndef CONTAINER_H
#define CONTAINER_H

#include <string>
using namespace std;

namespace LibrarySystem {

template <class T>
class Container {
private:
    T* data;
    int size;
    int capacity;

    void resize() {
        capacity *= 2;

        T* temp = new T[capacity];

        for (int i = 0; i < size; i++) {
            temp[i] = data[i];
        }

        delete[] data;
        data = temp;
    }

public:
    Container() {
        size = 0;
        capacity = 5;
        data = new T[capacity];
    }

    Container(const Container& other) {
        size = other.size;
        capacity = other.capacity;
        data = new T[capacity];

        for (int i = 0; i < size; i++) {
            data[i] = other.data[i];
        }
    }

    ~Container() {
        delete[] data;
    }

    Container& operator=(const Container& other) {
        if (this != &other) {
            delete[] data;

            size = other.size;
            capacity = other.capacity;
            data = new T[capacity];

            for (int i = 0; i < size; i++) {
                data[i] = other.data[i];
            }
        }

        return *this;
    }

    void add(const T& item) {
        if (size == capacity) {
            resize();
        }

        data[size] = item;
        size++;
    }

    void remove(int index) {
        if (index < 0 || index >= size) {
            return;
        }

        for (int i = index; i < size - 1; i++) {
            data[i] = data[i + 1];
        }

        size--;
    }

    T* find(int id) {
        for (int i = 0; i < size; i++) {
            if (data[i].getId() == id) {
                return &data[i];
            }
        }

        return nullptr;
    }

    T* find(string name) {
        for (int i = 0; i < size; i++) {
            if (data[i].getName() == name) {
                return &data[i];
            }
        }

        return nullptr;
    }

    T& operator[](int index) {
        return data[index];
    }

    const T& operator[](int index) const {
        return data[index];
    }

    int getSize() const {
        return size;
    }
};

}

#endif