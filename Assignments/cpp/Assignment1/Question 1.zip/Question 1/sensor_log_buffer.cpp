#include <iostream>
using namespace std;

int main() {

    int n;
    double arr[100];

    cout << "Enter the number of readings: ";
    cin >> n;

    if (n < 1 || n > 100) {
        cout << "Invalid number of readings." << endl;
        return 0;
    }

    cout << "Enter the temperature readings:" << endl;

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int normal = 0;
    int warning = 0;
    int critical = 0;
    int shutdown = 0;

    double minTemp = 0;
    double maxTemp = 0;
    double sum = 0;

    int validCount = 0;
    bool firstvalid = true;

    // Process valid readings
    for (int i = 0; i < n; i++) {

        if (arr[i] < 0) {
            continue;
        }

        cout << "Valid reading: " << arr[i] << endl;

        validCount++;

        if (firstvalid) {
            minTemp = arr[i];
            maxTemp = arr[i];
            firstvalid = false;
        }

        if (arr[i] < minTemp) {
            minTemp = arr[i];
        }

        if (arr[i] > maxTemp) {
            maxTemp = arr[i];
        }

        sum += arr[i];
    }

    // Find first reading >= 45
    for (int i = 0; i < n; i++) {

        if (arr[i] < 0) {
            continue;
        }

        if (arr[i] >= 45) {
            cout << "First reading at or above 45 is at index: "
                 << i << endl;
            break;
        }
    }

    // Categorize readings
    for (int i = 0; i < n; i++) {

        if (arr[i] < 0) {
            continue;
        }

        if (arr[i] < 30) {
            normal++;
        }
        else if (arr[i] < 40) {
            warning++;
        }
        else if (arr[i] < 50) {
            critical++;
        }
        else {
            shutdown++;
        }
    }

    // Check whether any valid reading exists
    if (firstvalid) {
        cout << "No valid readings available." << endl;
    }
    else {

        double average = sum / validCount;

        cout << "\n--- Status Report ---" << endl;

        cout << "Minimum: " << minTemp << endl;
        cout << "Maximum: " << maxTemp << endl;
        cout << "Average: " << average << endl;

        cout << "\nCategories:" << endl;

        cout << "Normal: " << normal << endl;
        cout << "Warning: " << warning << endl;
        cout << "Critical: " << critical << endl;
        cout << "Shutdown: " << shutdown << endl;
    }

    return 0;
}