#include "../headers/Book.h"

namespace LibrarySystem {

Book::Book() {
    bookId = 0;
    title = "";
    author = "";
    isbn = "";
    status = BookStatus::AVAILABLE;
    genre = BookGenre::FICTION;
    quantity = 0;
    availableCopies = 0;
}

Book::Book(int id, string title, string author, string isbn,
           BookGenre genre, int quantity) {

    this->bookId = id;
    this->title = title;
    this->author = author;
    this->isbn = isbn;
    this->genre = genre;
    this->quantity = quantity;
    this->availableCopies = quantity;
    status = BookStatus::AVAILABLE;
}

int Book::getId() const {
    return bookId;
}

int Book::getBookId() const {
    return bookId;
}

string Book::getTitle() const {
    return title;
}

string Book::getAuthor() const {
    return author;
}

string Book::getIsbn() const {
    return isbn;
}

BookStatus Book::getStatus() const {
    return status;
}

BookGenre Book::getGenre() const {
    return genre;
}

int Book::getQuantity() const {
    return quantity;
}

int Book::getAvailableCopies() const {
    return availableCopies;
}

void Book::issueBook() {
    if (availableCopies > 0) {
        availableCopies--;

        if (availableCopies == 0) {
            status = BookStatus::ISSUED;
        }
    }
}

void Book::returnBook() {
    if (availableCopies < quantity) {
        availableCopies++;
        status = BookStatus::AVAILABLE;
    }
}

bool Book::operator==(const Book& other) const {
    return bookId == other.bookId;
}

bool Book::operator<(const Book& other) const {
    return title < other.title;
}

Book& Book::operator++() {
    quantity++;
    availableCopies++;
    status = BookStatus::AVAILABLE;

    return *this;
}

Book Book::operator++(int) {
    Book temp = *this;
    ++(*this);

    return temp;
}

Book& Book::operator--() {
    if (quantity > 0) {
        quantity--;

        if (availableCopies > quantity) {
            availableCopies = quantity;
        }

        if (availableCopies > 0) {
            status = BookStatus::AVAILABLE;
        } else {
            status = BookStatus::ISSUED;
        }
    }

    return *this;
}

string Book::operator[](int index) const {
    switch (index) {
        case 0:
            return to_string(bookId);

        case 1:
            return title;

        case 2:
            return author;

        case 3:
            return isbn;

        case 4:
            return statusToString(status);

        case 5:
            return to_string(quantity);

        case 6:
            return to_string(availableCopies);

        default:
            return "";
    }
}

string statusToString(BookStatus status) {
    if (status == BookStatus::AVAILABLE) {
        return "AVAILABLE";
    }

    return "ISSUED";
}

string genreToString(BookGenre genre) {
    switch (genre) {
        case BookGenre::FICTION:
            return "FICTION";

        case BookGenre::NON_FICTION:
            return "NON_FICTION";

        case BookGenre::SCIENCE:
            return "SCIENCE";

        case BookGenre::TECHNOLOGY:
            return "TECHNOLOGY";

        case BookGenre::HISTORY:
            return "HISTORY";
    }

    return "FICTION";
}

ostream& operator<<(ostream& out, const Book& book) {
    out << book.bookId << " "
        << book.title << " "
        << book.author << " "
        << book.isbn << " "
        << statusToString(book.status) << " "
        << genreToString(book.genre) << " "
        << book.quantity << " "
        << book.availableCopies;

    return out;
}

istream& operator>>(istream& in, Book& book) {
    in >> book.bookId
       >> book.title
       >> book.author
       >> book.isbn
       >> book.quantity;

    book.availableCopies = book.quantity;
    book.status = BookStatus::AVAILABLE;

    return in;
}

}