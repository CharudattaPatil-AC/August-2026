#include "../headers/Member.h"

namespace LibrarySystem {

Member::Member() : Person() {
    issuedCount = 0;
    issuedBookIds = new int[5];
}

Member::Member(int id, string name, string phone)
    : Person(id, name, phone) {
    issuedCount = 0;
    issuedBookIds = new int[5];
}

Member::Member(const Member& other)
    : Person(other.id, other.name, other.phone) {

    issuedCount = other.issuedCount;
    issuedBookIds = new int[5];

    for (int i = 0; i < issuedCount; i++) {
        issuedBookIds[i] = other.issuedBookIds[i];
    }
}

Member::~Member() {
    delete[] issuedBookIds;
}

Member& Member::operator=(const Member& other) {
    if (this != &other) {
        id = other.id;
        name = other.name;
        phone = other.phone;
        issuedCount = other.issuedCount;

        delete[] issuedBookIds;
        issuedBookIds = new int[5];

        for (int i = 0; i < issuedCount; i++) {
            issuedBookIds[i] = other.issuedBookIds[i];
        }
    }

    return *this;
}

bool Member::operator==(const Member& other) const {
    return id == other.id;
}

void Member::addBook(int bookId) {
    if (issuedCount < 5) {
        issuedBookIds[issuedCount] = bookId;
        issuedCount++;
    }
}

void Member::removeBook(int bookId) {
    for (int i = 0; i < issuedCount; i++) {
        if (issuedBookIds[i] == bookId) {
            for (int j = i; j < issuedCount - 1; j++) {
                issuedBookIds[j] = issuedBookIds[j + 1];
            }

            issuedCount--;
            break;
        }
    }
}

bool Member::hasBook(int bookId) const {
    for (int i = 0; i < issuedCount; i++) {
        if (issuedBookIds[i] == bookId) {
            return true;
        }
    }

    return false;
}

int Member::getIssuedCount() const {
    return issuedCount;
}

void Member::displayInfo() const {
    cout << "Member ID: " << id << endl;
    cout << "Name: " << name << endl;
    cout << "Phone: " << phone << endl;
    cout << "Books Issued: " << issuedCount << endl;
}

ostream& operator<<(ostream& out, const Member& member) {
    out << member.id << " "
        << member.name << " "
        << member.phone;

    return out;
}

istream& operator>>(istream& in, Member& member) {
    in >> member.id;
    in >> member.name;
    in >> member.phone;

    return in;
}

}