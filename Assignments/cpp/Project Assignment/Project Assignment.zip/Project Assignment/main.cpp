#include "headers/Library.h"
#include <iostream>

using namespace std;
using namespace LibrarySystem;

int main() {
    Library library;
    int choice;

    do {
        cout << "\n========== LIBRARY MANAGEMENT SYSTEM ==========\n";
        cout << "1. Add New Book\n";
        cout << "2. Remove Book\n";
        cout << "3. Search Book\n";
        cout << "4. Display All Books\n";
        cout << "5. Register Member\n";
        cout << "6. Remove Member\n";
        cout << "7. Search Member\n";
        cout << "8. Display All Members\n";
        cout << "9. Issue Book\n";
        cout << "10. Return Book\n";
        cout << "11. View Overdue Books\n";
        cout << "12. Save Data\n";
        cout << "13. Load Data\n";
        cout << "14. Test Polymorphism\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        try {
            switch (choice) {
                case 1:
                    library.addBook();
                    break;

                case 2:
                    library.removeBook();
                    break;

                case 3:
                    library.searchBook();
                    break;

                case 4:
                    library.displayBooks();
                    break;

                case 5:
                    library.registerMember();
                    break;

                case 6:
                    library.removeMember();
                    break;

                case 7:
                    library.searchMember();
                    break;

                case 8:
                    library.displayMembers();
                    break;

                case 9:
                    library.issueBook();
                    break;

                case 10:
                    library.returnBook();
                    break;

                case 11:
                    library.viewOverdueBooks();
                    break;

                case 12:
                    library.saveData();
                    break;

                case 13:
                    library.loadData();
                    break;

                case 14:
                    library.polymorphismTest();
                    break;

                case 0:
                    cout << "Program ended.\n";
                    break;

                default:
                    cout << "Invalid choice.\n";
            }
        }
        catch (const LibraryException& e) {
            cout << "Error: " << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}