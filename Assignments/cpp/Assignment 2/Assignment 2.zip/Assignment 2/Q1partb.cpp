#include<iostream>
using namespace std;
double reorderCost(int qty, double unitPrice){
    return qty*unitPrice;
}
double reorderCost(double qty, double unitPrice){
    return qty*unitPrice;
}
double reorderCost(int qty, double unitPrice, double taxRate){
    double cost=qty*unitPrice;
    double tax=cost*taxRate/100;
    return cost+tax;
}
double applyDiscount(double price, double discountPercent = 10.0)
{
    return price - (price * discountPercent / 100);
}
int main(){
    double cost1=reorderCost(10,50.0);
    double cost2=reorderCost(10.5,50.0);
    double cost3=reorderCost(10,50.0,18.0);
    double discount1=applyDiscount(1000);
    double discount2=applyDiscount(1000,20.0);
    cout << "Integer Quantity Cost: " << cost1 << endl;
    cout << "Fractional Quantity Cost: " << cost2 << endl;
    cout << "Cost with Tax: " << cost3 << endl;

    cout << "Price after Default 10% Discount: "
         << discount1 << endl;

    cout << "Price after 20% Discount: "
         << discount2 << endl;

    return 0;
    
}
