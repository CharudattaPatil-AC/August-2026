#include <iostream>
using namespace std;
class Product{
    private:
    int productId;
    string name;
    double price;
    int quantity;

    public:
    void acceptDetails(){
        cout<<"Enter the product Id: "<<endl;
        cin>>productId;
        cout<<"Enter the name of the product"<<endl;
        cin>>name;
        cout<<"Enter the price: "<<endl;
        cin>>price;
        cout<<"Enter the quantity of the product: "<<endl;
        cin>>quantity;

    }
    void displayDetails() const{
        
        cout << productId << "\t"<< name<<"\t"<< price << "\t"<< quantity << "\t"<< totalValue()<<endl;
        
    }
    double totalValue() const{
        return price*quantity;
    }
    bool isLowStock(int threshold) const{
        return quantity<threshold;
    }

};
int main(){
    Product products[5];
    for(int i=0;i<5;i++){
        cout<<"Enter the details of Product "<<i+1<<endl;
        products[i].acceptDetails();
    }
    cout << "\n===== INVENTORY REPORT =====" << endl;
    cout << "Id\tName\tPrice\tQty\tTotal Value" << endl;

    for (int i=0;i<5;i++){
        products[i].displayDetails();
    }
    int highestIndex=0;
    for (int i=0;i<5;i++){
        if(products[i].totalValue()>products[highestIndex].totalValue()){
            highestIndex=i;
        }
    }
    cout<<"\nHighest Value Product: ";
    products[highestIndex].displayDetails();
    int threshold;
    cout<<"\n Enter low stock threshold: ";
    cin>>threshold;
    cout<<"\n Low Stock Products: "<<endl;
    for (int i=0;i<5;i++){
        if(products[i].isLowStock(threshold))
        {
            products[i].displayDetails();
        }
    }
    return 0;

}