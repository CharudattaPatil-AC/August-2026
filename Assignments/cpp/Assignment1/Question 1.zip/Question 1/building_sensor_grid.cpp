#include<iostream>
using namespace std;
int main(){
    int temp [3][3];
    cout<<"Enter the tempreture for all rooms: "<<endl;
    for (int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            cin>>temp[i][j];
        }
    }
    cout<<"\nTempreture Table:"<<endl;
    cout<<"\troom 1\troom 2\troom 3";
    cout<<endl;
    for(int i=0;i<3;i++){
        cout<<"floor"<<i+1<<":";
        for(int j=0;j<3;j++){
        cout<<"\t "<< temp[i][j]<<" ";
        }
        cout<<endl;
    }
    double hottest=temp[0][0];
    int hotRoom=0;
    int hotFloor=0;
    for (int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if(temp[i][j]>hottest){
                hottest=temp[i][j];
                hotFloor=i;
                hotRoom=j;
            }

        }
    }
    cout<<"\n Hottest Room: Floor "<<hotFloor+1<<",Room "<<hotRoom+1<<"->"<<hottest;
    double avg=0;
    double highestavg=0;
    int highestfloor=0;
    
    for (int i=0;i<3;i++){
        double sum=0;    
        for (int j=0;j<3;j++){
            sum=sum+temp[i][j];
        }
        avg=sum/3;
        if(avg>highestavg){
            highestavg=avg;
            highestfloor=i;

        }
    }
    cout<<"\nHottest Floor: Floor "<<highestfloor+1<<"(avg "<<highestavg<<" C)"<<endl;
    int count=0;
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if(temp[i][j]>=30){
                count++;
            }
        }
    }
    cout<<"Rooms at Warning or above: "<<count;
    return 0;
}   