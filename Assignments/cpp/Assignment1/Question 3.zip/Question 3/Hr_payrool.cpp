#include <iostream>
using namespace std;
class Employee{
    private:
    int empId;
    string name;
    string department;
    char grade;
    double basicSalary;
    bool isActive;
    


    static int employeeCount;

    public:
    void initialize()
    {
        empId = 1000 + ++employeeCount;

        name = "";
        department = "";
        grade = 'D';
        basicSalary = 0;
        isActive = true;
    }
    void setName(const string &n){
        if(n.empty()){
            cout<<"ERROR: Name cannot be empty. Value rejected"<<endl;
        }else{
            name=n;
        }
    }
    void setDepartment(const string &dept){
        if(dept=="Engineering"|| dept=="HR"||dept=="Finance"||dept=="Operations"){
            department=dept;

        }else{
            cout<<"ERROR: "<<dept<<" is not a recognsied department"<<endl;
        }
    }
    void setGrade(char g){
        if(g=='A'||g=='B'||g=='C'||g=='D'){
            grade=g;
        }
        else{
            cout<<"ERROR: "<<g<<" is not a recognised grade"<<endl;
        }
    }
    void setBasicSalary(double salary){
        if(salary>10000||salary<500000){
            basicSalary=salary;
        } else{
            cout<<"ERROR: Salary must be between Rs.10,000 and Rs. 5,00,000. Vlaue rejected"<<endl;
        }
    }
    void deactivated(){
        isActive=false;
    }

    int getEmpId() const{
        return empId;
    }
    string getName(){
        return name;
    }
    string getDepartmennt(){
        return department;
    }
    char getGrade(){
        return grade;
    }
    double getBasicSalary(){
        return basicSalary;
    }
    bool getIsActive() const{
        return isActive;
    }

    double computeAllowances() const{
        if(grade=='A')
            return basicSalary*0.40;
        else if(grade=='B')
            return basicSalary*0.30;
        else if(grade=='C')
            return basicSalary*0.20;
        else 
            return basicSalary*0.10;
    }

    double computeGrossSalary() const{
        return basicSalary+computeAllowances();
    }
    
    double computeTax() const{
        double gross=computeGrossSalary();
        
        if(gross<=50000){
            return 0;
        }
        else if(gross<=100000){
            return(gross-50000)*0.10;
        } else{
            return 5000+(gross-100000)*0.20;
        }
    }
    double computeNetSalary() const{
        return computeGrossSalary()-computeTax();
    }
    void acceptDetails(){
        string n;
        string dept;
        char g;
        double salary;
        cout<<"Enter Name: "<<endl;
        cin>>n;
        setName(n);
        cout<<"Enter Department: "<<endl;
        cin>>dept;
        setDepartment(dept);
        cout<<"Enter grade: "<<endl;
        cin>>g;
        setGrade(g);
        cout<<"Enter basic salary: "<<endl;
        cin>>salary;
        setBasicSalary(salary);
    }

    void printPayslip() const
    {
        cout<<"\n============================================"<<endl;
        cout<<"\n       EMPLOYEE PAYSLIP — AUG 2026          "<<endl;
        cout<<"\n============================================"<<endl;
        cout<<"Emp ID     : "<<empId<<endl;
        cout<<"Name       : "<<name<<endl;
        cout<<"Department : "<<department<<endl;
        cout<<"Grade      : "<<grade<<endl;
        cout<<"Status     : "<<(isActive?"Active":"Inactive")<<endl;
        cout<<"\n--------------------------------------------"<<endl;
        cout<<"Basic Salary :Rs. "<<basicSalary<<endl;
        cout<<"Allowances   :Rs. "<<computeAllowances()<<endl;
        cout<<"Gross Salary :Rs. "<<computeGrossSalary()<<endl;
        cout<<"\n--------------------------------------------"<<endl;
        cout<<"Tax Deduction :Rs. "<<computeTax()<<endl;
        cout<<"Net Salary    :Rs. "<<computeNetSalary()<<endl;
        cout<<"\n============================================"<<endl;
        


        
    }
    static int getEmployeeCount(){
            return employeeCount;
        }
};

int Employee::employeeCount=0;

int main() {
// Create objects — one on stack, two on heap
    Employee e1;
    Employee* e2 = new Employee();
    Employee* e3 = new Employee();
    e1.acceptDetails();
    e2->acceptDetails();
    e3->acceptDetails();
// Try uncommenting — observe the compiler error, then explain in a comment why

// e1.empId = 999;
// e1.basicSalary = -1000;
    e1.printPayslip();
    e2->printPayslip();
    e3->printPayslip();
    // Simulate a resignation
    e3->deactivated();
    if (!e3->getIsActive())
    cout << e3->getName() << " is no longer active. Payroll skipped." << endl;
    cout << "Total Employees : " << Employee::getEmployeeCount() << endl;
    delete e2;
    delete e3;
    return 0;
}