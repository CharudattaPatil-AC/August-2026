        cout << "5. Register Member\n";
