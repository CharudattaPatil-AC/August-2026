#include "../headers/Library.h"
#include "../headers/Librarian.h"
#include <iostream>
#include <fstream>

namespace LibrarySystem {

void Library::addBook() {
    int id;
    string title, author, isbn;
    int genre;
    int quantity;

    cout << "Enter book ID: ";
    cin >> id;

    cout << "Enter title: ";
    cin >> title;

    cout << "Enter author: ";
    cin >> author;

    cout << "Enter ISBN: ";
    cin >> isbn;

    cout << "Enter genre 1-Fiction 2-Non-Fiction 3-Science 4-Technology 5-History: ";
    cin >> genre;

    cout << "Enter quantity: ";
    cin >> quantity;

    BookGenre selectedGenre = BookGenre::FICTION;

    if (genre == 2) selectedGenre = BookGenre::NON_FICTION;
    else if (genre == 3) selectedGenre = BookGenre::SCIENCE;
    else if (genre == 4) selectedGenre = BookGenre::TECHNOLOGY;
    else if (genre == 5) selectedGenre = BookGenre::HISTORY;

    books.add(Book(id, title, author, isbn, selectedGenre, quantity));

    cout << "Book added successfully.\n";
}

void Library::removeBook() {
    int id;

    cout << "Enter book ID: ";
    cin >> id;

    Book* book = books.find(id);

    if (book == nullptr) {
        throw BookNotFoundException(__FUNCTION__, __LINE__);
    }

    for (int i = 0; i < books.getSize(); i++) {
        if (books[i].getBookId() == id) {
            books.remove(i);
            break;
        }
    }

    cout << "Book removed successfully.\n";
}

void Library::searchBook() {
    int id;

    cout << "Enter book ID: ";
    cin >> id;

    Book* book = books.find(id);

    if (book == nullptr) {
        throw BookNotFoundException(__FUNCTION__, __LINE__);
    }

    cout << *book << endl;
}

void Library::displayBooks() {
    if (books.getSize() == 0) {
        cout << "No books available.\n";
        return;
    }

    for (int i = 0; i < books.getSize(); i++) {
        cout << "\nBook " << i + 1 << endl;
        cout << books[i] << endl;
    }
}

void Library::registerMember() {
    int id;
    string name, phone;

    cout << "Enter member ID: ";
    cin >> id;

    cout << "Enter name: ";
    cin >> name;

    cout << "Enter phone: ";
    cin >> phone;

    members.add(Member(id, name, phone));

    cout << "Member registered successfully.\n";
}

void Library::removeMember() {
    int id;

    cout << "Enter member ID: ";
    cin >> id;

    Member* member = members.find(id);

    if (member == nullptr) {
        throw MemberNotFoundException(__FUNCTION__, __LINE__);
    }

    for (int i = 0; i < members.getSize(); i++) {
        if (members[i].getId() == id) {
            members.remove(i);
            break;
        }
    }

    cout << "Member removed successfully.\n";
}

void Library::searchMember() {
    int id;

    cout << "Enter member ID: ";
    cin >> id;

    Member* member = members.find(id);

    if (member == nullptr) {
        throw MemberNotFoundException(__FUNCTION__, __LINE__);
    }

    member->displayInfo();
}

void Library::displayMembers() {
    if (members.getSize() == 0) {
        cout << "No members registered.\n";
        return;
    }

    for (int i = 0; i < members.getSize(); i++) {
        cout << "\nMember " << i + 1 << endl;
        members[i].displayInfo();
    }
}

void Library::issueBook() {
    int bookId;
    int memberId;

    cout << "Enter book ID: ";
    cin >> bookId;

    cout << "Enter member ID: ";
    cin >> memberId;

    Book* book = books.find(bookId);

    if (book == nullptr) {
        throw BookNotFoundException(__FUNCTION__, __LINE__);
    }

    Member* member = members.find(memberId);

    if (member == nullptr) {
        throw MemberNotFoundException(__FUNCTION__, __LINE__);
    }

    if (book->getAvailableCopies() <= 0) {
        throw BookNotAvailableException(__FUNCTION__, __LINE__);
    }

    if (member->getIssuedCount() >= 5) {
        throw MaxBooksExceededException(__FUNCTION__, __LINE__);
    }

    book->issueBook();
    member->addBook(bookId);

    issuedBooks[bookId] = memberId;

    Transaction transaction(
        memberId,
        bookId,
        "09-09-2026",
        "16-09-2026"
    );

    transactions.push_back(transaction);

    cout << "Book issued successfully.\n";
}

void Library::returnBook() {
    int bookId;

    cout << "Enter book ID: ";
    cin >> bookId;

    Book* book = books.find(bookId);

    if (book == nullptr) {
        throw BookNotFoundException(__FUNCTION__, __LINE__);
    }

    auto it = issuedBooks.find(bookId);

    if (it == issuedBooks.end()) {
        cout << "This book is not currently issued.\n";
        return;
    }

    int memberId = it->second;

    Member* member = members.find(memberId);

    if (member != nullptr) {
        member->removeBook(bookId);
    }

    book->returnBook();

    issuedBooks.erase(it);

    cout << "Enter number of late days: ";
    int lateDays;
    cin >> lateDays;

    if (!transactions.empty()) {
        transactions.back().calculateFine(lateDays);
        transactions.back().setReturnDate("09-09-2026");
    }

    cout << "Book returned successfully.\n";

    if (lateDays > 0) {
        cout << "Fine: " << lateDays * 5 << endl;
    }
}

void Library::viewOverdueBooks() {
    if (transactions.empty()) {
        cout << "No transactions available.\n";
        return;
    }

    for (const auto& transaction : transactions) {
        if (transaction.getFineAmount() > 0) {
            transaction.display();
            cout << endl;
        }
    }
}

void Library::saveData() {
    ofstream bookFile("data/books.txt");
    ofstream memberFile("data/members.txt");
    ofstream transactionFile("data/transactions.txt");

    for (int i = 0; i < books.getSize(); i++) {
        bookFile << books[i][0] << "|"
                 << books[i][1] << "|"
                 << books[i][2] << "|"
                 << books[i][3] << "|"
                 << books[i][4] << "|"
                 << books[i][5] << "|"
                 << books[i][6] << endl;
    }

    for (int i = 0; i < members.getSize(); i++) {
        memberFile << members[i].getId() << "|"
                   << members[i].getName() << "|"
                   << members[i].getPhone() << endl;
    }

    for (const auto& transaction : transactions) {
        transactionFile << transaction.getTransactionId() << "|"
                        << transaction.getMemberId() << "|"
                        << transaction.getBookId() << "|"
                        << transaction.getFineAmount() << endl;
    }

    bookFile.close();
    memberFile.close();
    transactionFile.close();

    cout << "Data saved successfully.\n";
}

void Library::loadData() {
    cout << "Data loading completed.\n";
}

void Library::polymorphismTest() {
    Person* person = new Member(1, "Rahul", "9876543210");

    person->displayInfo();

    delete person;
}

}