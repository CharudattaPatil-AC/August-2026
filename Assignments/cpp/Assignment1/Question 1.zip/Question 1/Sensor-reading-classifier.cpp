#include<iostream>
using namespace std;
int main(){
    double temp;
    int statusCode;
    float F;                                                                           
    cout<<"Enter the temp in degree celcius"<<endl;
    cin>>temp;
    F = (temp * 9 / 5) + 32;
    if (temp<0){
        statusCode=-1;
    } else if(temp>=0 && temp<=20){
        statusCode=0;
    } else if(temp >=30  && temp<=44){
        statusCode=1;
    } else if(temp>=45 && temp <=59){
        statusCode=2;
    } else{
        statusCode=3;
    }

    cout<<"Temperature  : "<<temp<<" / "<<F<<endl;
    switch(statusCode){
        case -1:
        cout<<"STATUS       : "<<"SENSOR_ERROR"<<endl;
        cout<<"Action       : "<<"Sensor fault — check wiring"<<endl;
        break;
        case 0:
        cout<<"Status       : "<<"NORMAL"<<endl;
        cout<<"Action       : "<<"No action required"<<endl;
        break;
        case 1:
        cout<<"STATUS       : "<<"WARNING"<<endl;
        cout<<"Action       : "<<"Alert sent to supervisor"<<endl;
        break;
        case 2:
        cout<<"STATUS       : "<<"CRITICAL"<<endl;
        cout<<"Action       : "<<"Cooling system triggered"<<endl;
        break;
        case 3:
        cout<<"STATUS       : "<<"SHUTDOWN"<<endl;
        cout<<"Action       : "<<"Emergency shutdown initiated"<<endl;
        break;
        default:
        cout<<"Invalid status code"<<endl;

    }
    cout<<"Reading      : "<<(temp>25 ? "Above Average ": "Below Average")<<endl;
    return 0;



}