#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
using namespace std;

namespace LibrarySystem {

class Transaction {
private:
    int transactionId;
    int memberId;
    int bookId;
    string issueDate;
    string dueDate;
    string returnDate;
    double fineAmount;

    static int nextId;
    static const double fineRate;

public:
    Transaction();
    Transaction(int memberId, int bookId, string issueDate, string dueDate);

    int getTransactionId() const;
    int getMemberId() const;
    int getBookId() const;
    double getFineAmount() const;

    void setReturnDate(string returnDate);
    void calculateFine(int lateDays);

    void display() const;
};

}

#endif