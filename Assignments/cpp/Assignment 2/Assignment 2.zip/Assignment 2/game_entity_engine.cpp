#include<iostream>
#include<ctime>
using namespace std;
int level = 1; 
class Entity{
    private:
    string name;
    int health;
    int level;
    string type;
    public:
    Entity &setName(const string &name){
        this-> name=name;
        return *this;
    }
    Entity &setHealth(int health){
        this->health=health;
        return *this;
    }
    Entity &setLevel(int level){
        this->level=level;
        return *this;
    }
    Entity &setType(const string&type){
        this->type=type;
        return *this;
    }
    string getName()const{
        return name;
    }
    int getHealth()const{
        return health;
    }
    int getLevel()const{
        return level;
    }
    string getType()const{
        return type;
    }
    void displayInfo() const{
        cout<<"Name   : "<<name<<endl;
        cout<<"Health : "<<health<<endl;
        cout<<"Level  : "<<level<<endl;
        cout<<"Type   : "<<type<<endl;
        cout<<"----------------------"<<endl;
    }

};
namespace Physics{
    double clamp(double val,double min,double max){
        if(val<min){
            return min;
        }else if(val>max){
            return max;
        } else{
            return val;
        }

    }
    double lerp(double a, double b,double t){
        return a/(b-a)*t;
    }
}
namespace GameMath{
    int clamp(int val,int min,int max){
        if(val<min)
            return min;
        if(val<max)
            return max;
        return val;
    }
    double lerp(double a, double b, double t){
        return a/(b-a)*t;
    }
}

namespace Engine{
    namespace Audio{
        void playSound(string name){
            cout<<"Playing: "<<name<<endl;
        }
    }
}

void createGameMap(){
    int R,C;
    cout<<"\n Enter number of rows: ";
    cin>>R;
    cout<<"Enter number of columns: ";
    cin>>C;
    int **gameMap=new int*[R];
    for (int i=0;i<R;i++){
        gameMap[i]=new int[C];
    }
    srand(static_cast<unsigned int>(time(nullptr)));
    for(int i=0;i<R;i++){
        for(int j=0;j<C;j++){
            gameMap[i][j]=rand()%5;
        }
    }
    cout<<"\n==== Game Map(" << R << " x "<< C <<") ====="<<endl;
    for(int i=0;i<R;i++){
        for(int j=0;j<C;j++){
            cout<<gameMap[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<"\nLegend: "<<"0=Grass "<<"1=Water "<<"2=Mountain "<<"3=Forest "<<"4=Dungeon "<<endl;
    int titleCount[5]={0};
    for(int i=0;i<R;i++){
        for(int j=0;j<C;j++){
            titleCount[gameMap[i][j]]++;
        }
    }
    cout<<"\nTitle Count: "<<titleCount[0]<<endl;
    cout<<"Grass        : "<<titleCount[1]<<endl;
    cout<<"Water        : "<<titleCount[2]<<endl;
    cout<<"Mountain     : "<<titleCount[3]<<endl;
    cout<<"Forest       : "<<titleCount[4]<<endl;
    cout<<"Dungeon      : "<<titleCount[4]<<endl;
    for(int i=0;i<R;i++){
        delete[]gameMap[i];
    }
    delete[]gameMap;
    cout<<"\nGame map memory deallocated successfully. "<<endl;
    
}
int main(){
    Entity player,enemy, item;
    player.setName("Aragorn").setHealth(100).setLevel(10).setType("Player");
    enemy.setName("Orc").setHealth(60).setLevel(5).setType("Enemy");
    item.setName("HealthPotion").setHealth(0).setLevel(1).setType("Item");
    cout<<"======== Entity Information ======================"<<endl;
    player.displayInfo();
    enemy.displayInfo();
    item.displayInfo();
    double velocity=125.5;
    double clampedVelocity=Physics ::clamp(velocity,0.0,100.0);
    cout<<"==== Namespace Demo ============"<<endl;
    cout<<"Original Velocity : "<<velocity<<endl;
    cout<<"Clamped velocity   : "<<clampedVelocity<<endl;
    int health=150;
    int clampedHealth=GameMath::clamp(health,0,100);
    cout<<"Original health    : "<<health<<endl;
    cout<<"Clamped health     : "<<clampedHealth<<endl;
    cout<<"Physics lerp       : "<<Physics::lerp(0.0,100.0,0.5)<<endl;
    cout << "GameMath lerp    : "<< GameMath::lerp(10.0, 20.0, 0.25) << endl;
    {
        using namespace GameMath;
        int value=clamp(10,0,100);
        cout<<"Limited-scope clamp: "<<value<<endl;
    }
    int level = player.getLevel();
    cout<<"\n====== Scope Resolution Demo ======="<<endl;
    cout<<"Local player level : "<<level<<endl;
    cout<<"Global game level  : "<< ::level<<endl;
    Engine::Audio::playSound("sword_clash");

    createGameMap();
    return 0;
}

