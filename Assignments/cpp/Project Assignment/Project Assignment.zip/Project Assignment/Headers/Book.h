#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include <string>
using namespace std;

namespace LibrarySystem {

enum class BookStatus {
    AVAILABLE,
    ISSUED
};

enum class BookGenre {
    FICTION,
    NON_FICTION,
    SCIENCE,
    TECHNOLOGY,
    HISTORY
};

class Book {
private:
    int bookId;
    string title;
    string author;
    string isbn;
    BookStatus status;
    BookGenre genre;
    int quantity;
    int availableCopies;

public:
    Book();
    Book(int id, string title, string author, string isbn,
         BookGenre genre, int quantity);

    int getId() const;
    int getBookId() const;
    string getTitle() const;
    string getAuthor() const;
    string getIsbn() const;
    BookStatus getStatus() const;
    BookGenre getGenre() const;
    int getQuantity() const;
    int getAvailableCopies() const;

    void issueBook();
    void returnBook();

    bool operator==(const Book& other) const;
    bool operator<(const Book& other) const;

    Book& operator++();
    Book operator++(int);

    Book& operator--();

    string operator[](int index) const;

    friend ostream& operator<<(ostream& out, const Book& book);
    friend istream& operator>>(istream& in, Book& book);
};

string statusToString(BookStatus status);
string genreToString(BookGenre genre);

}

#endif