#ifndef LIBRARIAN_H
#define LIBRARIAN_H

#include "Person.h"
using namespace std;

namespace LibrarySystem {

class Librarian : public Person {
private:
    int employeeId;
    double salary;

public:
    Librarian();
    Librarian(int id, string name, string phone, int employeeId, double salary);

    int getEmployeeId() const;
    double getSalary() const;

    void displayInfo() const override;
};

}

#endif