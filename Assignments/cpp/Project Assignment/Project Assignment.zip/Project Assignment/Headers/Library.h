#ifndef LIBRARY_H
#define LIBRARY_H

#include "Book.h"
#include "Member.h"
#include "Container.h"
#include "Transaction.h"
#include "Exceptions.h"
#include <vector>
#include <map>
#include <string>
using namespace std;

namespace LibrarySystem {

class Library {
private:
    Container<Book> books;
    Container<Member> members;
    vector<Transaction> transactions;
    map<int, int> issuedBooks;

public:
    void addBook();
    void removeBook();
    void searchBook();
    void displayBooks();

    void registerMember();
    void removeMember();
    void searchMember();
    void displayMembers();

    void issueBook();
    void returnBook();
    void viewOverdueBooks();

    void saveData();
    void loadData();

    void polymorphismTest();
};

}

#endif