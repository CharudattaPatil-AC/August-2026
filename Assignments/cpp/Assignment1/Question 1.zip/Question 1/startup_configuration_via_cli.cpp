#include<iostream>
#
using namespace std;
int main(int argc,char*argv[]){
    if(argc!=4){
        cout<<"Usage:./sensor_moniter "<<"<warn_threshold>"<<"  <critical_threshold>"<<"  <num_readings>"<<endl;
        cout<<"Error:Missing Arguments "<<endl;
        return 1;
    }
    int warn=atoi(argv[1]);
    int critical=atoi(argv[2]);
    int reading=atoi(argv[3]);
    if(warn>=critical){
        cout<<"Error: warn_threshold must be less than critical_threhold"<<endl;
        return 1;
    }
    if(reading <1 || reading>500){
        cout<<"Error: num_readings must be 1 to 500"<<endl;
        return 1;
    }
    cout<<"Config: warn="<<warn<<"Critical= "<<critical<<"Reading= "<<reading<<endl;
    int normal=0;
    int warning=0;
    int criticalCount=0;
    for(int i=0;i<reading;i++){
        int tempreture=rand()%70;
        if(tempreture<warn){
            normal++;
        } else if(tempreture<critical){
            warning++;
        } else{
            criticalCount++;
        }
    }
    cout<<"Results: Normal: "<<normal<<"\nWarning: "<<warning<<"\n Critical: "<<criticalCount<<endl;
    return 0;
 


}