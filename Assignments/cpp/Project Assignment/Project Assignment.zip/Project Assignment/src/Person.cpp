#include "../headers/Person.h"

namespace LibrarySystem {

Person::Person() {
    id = 0;
    name = "";
    phone = "";
}

Person::Person(int id, string name, string phone) {
    this->id = id;
    this->name = name;
    this->phone = phone;
}

Person::~Person() {
}

int Person::getId() const {
    return id;
}

string Person::getName() const {
    return name;
}

string Person::getPhone() const {
    return phone;
}

void Person::setName(string name) {
    this->name = name;
}

void Person::setPhone(string phone) {
    this->phone = phone;
}

}