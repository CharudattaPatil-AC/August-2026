#ifndef MEMBER_H
#define MEMBER_H

#include "Person.h"
#include <iostream>
using namespace std;

namespace LibrarySystem {

class Member : public Person {
private:
    int issuedCount;
    int* issuedBookIds;

public:
    Member();
    Member(int id, string name, string phone);
    Member(const Member& other);
    ~Member();

    Member& operator=(const Member& other);
    bool operator==(const Member& other) const;

    void addBook(int bookId);
    void removeBook(int bookId);
    bool hasBook(int bookId) const;

    int getIssuedCount() const;

    void displayInfo() const override;

    friend ostream& operator<<(ostream& out, const Member& member);
    friend istream& operator>>(istream& in, Member& member);
};

}

#endif