#include "../headers/Transaction.h"
#include <iostream>

namespace LibrarySystem {

int Transaction::nextId = 1;
const double Transaction::fineRate = 5.0;

Transaction::Transaction() {
    transactionId = nextId++;
    memberId = 0;
    bookId = 0;
    issueDate = "";
    dueDate = "";
    returnDate = "";
    fineAmount = 0;
}

Transaction::Transaction(int memberId, int bookId,
                         string issueDate, string dueDate) {

    transactionId = nextId++;
    this->memberId = memberId;
    this->bookId = bookId;
    this->issueDate = issueDate;
    this->dueDate = dueDate;
    returnDate = "";
    fineAmount = 0;
}

int Transaction::getTransactionId() const {
    return transactionId;
}

int Transaction::getMemberId() const {
    return memberId;
}

int Transaction::getBookId() const {
    return bookId;
}

double Transaction::getFineAmount() const {
    return fineAmount;
}

void Transaction::setReturnDate(string returnDate) {
    this->returnDate = returnDate;
}

void Transaction::calculateFine(int lateDays) {
    if (lateDays > 0) {
        fineAmount = lateDays * fineRate;
    } else {
        fineAmount = 0;
    }
}

void Transaction::display() const {
    cout << "Transaction ID: " << transactionId << endl;
    cout << "Member ID: " << memberId << endl;
    cout << "Book ID: " << bookId << endl;
    cout << "Issue Date: " << issueDate << endl;
    cout << "Due Date: " << dueDate << endl;
    cout << "Return Date: " << returnDate << endl;
    cout << "Fine: " << fineAmount << endl;
}

}