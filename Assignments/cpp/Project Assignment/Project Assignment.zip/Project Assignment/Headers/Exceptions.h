#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <exception>
#include <string>
using namespace std;

namespace LibrarySystem {

class LibraryException : public exception {
protected:
    string message;

public:
    LibraryException(string message) {
        this->message = message;
    }

    const char* what() const noexcept override {
        return message.c_str();
    }
};

class BookNotFoundException : public LibraryException {
public:
    BookNotFoundException(string functionName, int line)
        : LibraryException("Book not found in " + functionName +
                           " at line " + to_string(line)) {
    }
};

class MemberNotFoundException : public LibraryException {
public:
    MemberNotFoundException(string functionName, int line)
        : LibraryException("Member not found in " + functionName +
                           " at line " + to_string(line)) {
    }
};

class BookNotAvailableException : public LibraryException {
public:
    BookNotAvailableException(string functionName, int line)
        : LibraryException("Book is not available in " + functionName +
                           " at line " + to_string(line)) {
    }
};

class MaxBooksExceededException : public LibraryException {
public:
    MaxBooksExceededException(string functionName, int line)
        : LibraryException("Maximum books exceeded in " + functionName +
                           " at line " + to_string(line)) {
    }
};

}

#endif