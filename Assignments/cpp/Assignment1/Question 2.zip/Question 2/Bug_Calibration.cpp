#include <iostream>
using namespace std;
void resetSensorpairV1(int reading1,int reading2){
    int temp = reading1;
    reading1=reading2;
    reading2=temp;

}

void resetSensorPairV2(int& reading1, int& reading2){
    int temp=reading1;
    reading1=reading2;
    reading2=temp;
}

void resetSensorPairV3(int* reading1, int* reading2){
    int temp=*reading1;
    *reading1=*reading2;
    *reading2=temp;

}
int main(){
    int a,b;
    a=55;
    b=12;
    //call by value
    cout<<"\n--- V1: Call by Value ---"<<endl;
    cout<<"Before : A="<<a<<"  B="<<b<<endl;
    resetSensorpairV1(a,b);
    cout<<"After : A="<<a<<" B="<<b<<"<- values unchanged"<<endl;
    


    //call by reference
    cout<<"\n--- V1: Call by Reference ---"<<endl;
    cout<<"Before : A="<<a<<"  B="<<b<<endl;
    resetSensorPairV2(a,b);
    cout<<"After : A="<<a<<" B="<<b<<"<- values swapped"<<endl;
    
    //call by pointer
    cout<<"\n--- V1: Call by Pointer ---"<<endl;
    cout<<"Before : A="<<a<<"  B="<<b<<endl;
    resetSensorPairV3(&a,&b);
    cout<<"After : A="<<a<<" B="<<b<<"<- values swapped"<<endl;
    

    return 0 ;
    

}