#include <iostream>
using namespace std;
int main(){
    int statusReg  = 0b10110001;   
    int controlReg = 0b00000000;   
    int dataReg    = 0b11001010;
    const int *regPtr1=&statusReg;
    int * const regPtr2=&controlReg;
    const int *regPtr3=&statusReg;

    cout <<"Status register: "<<&regPtr1<<endl;

    *regPtr2=100;
    cout<<"Control register: "<<*regPtr2<<endl;
    
    cout<<"Status register using regPtr3: "<<*regPtr3<<endl;
    return 0;
}